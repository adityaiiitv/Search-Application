﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public int[] etime = new int[10];   // Array to store entry time
        public int[] ptime = new int[10];   // Array to store inter-record entry time    
        public int[] back = new int[10];    // Array to store count of backspaces for each record
        public string b;
        public int i = 0;
        public int nor = 10,minentry,maxentry,avgentry,mininter,maxinter,avginter,totime,toback;    // Variables to store items

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button2.Enabled = true; // Analyze button
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        public string i1;   // String to pass on the file name
        public Form1()
        {
            InitializeComponent();
        }

        public void update()    // To keep the list updated
        {
            // Creates a new list
            listView1.Items.Clear();    // Clear at first
            listView1.Size = new System.Drawing.Size(204, 250); // Set size
            listView1.Location = new System.Drawing.Point(10, 10);  // Initial position
            this.Controls.Add(listView1);   // Give control to listview1
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true; // Set defaults
            listView1.BeginUpdate();
            //
            //  To read the file
            //
            string path = Directory.GetCurrentDirectory();  // Get the current directory
            DirectoryInfo dinfo = new DirectoryInfo(@path);
            FileInfo[] Files = dinfo.GetFiles("*.txt");     // Get all files with .txt extension
            foreach (FileInfo file in Files)
            {
                listView1.Items.Add(file.Name);             // Add all files to listview
            }
            listView1.EndUpdate();  // Update the list
            return;
            //
        }
        private void Form1_DoubleClick(object sender, EventArgs e)
        {

        }

    
        private void listView1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
           
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                i1 = item.SubItems[0].Text; // i1 gives the selected item
            }
            label2.Text = "File selected: "+i1;
            textBox1.Text = "analysis";
            label1.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Default on loading the form
            i1 = "";
            button2.Enabled = false;
            listView1.Columns.Add("List of text files in the program directory:", 200); // Add the columns
            update();   // Update the list whenever the program is loaded
        }

        public void analyze(string a,string b)
        {
            using (StreamReader sr = new StreamReader(a))   // Stringreader to read the file
            {
                try
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)  // Read till EOF
                    {
                        String[] substrings = line.Split(',');  // Split the line into words when it encounters ,
                        // String to int
                        etime[i]=Int32.Parse(substrings[12]);ptime[i]=Int32.Parse(substrings[13]);back[i]=Int32.Parse(substrings[14]);
                        i=i+1;  // Increment
                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine("The file could not be read:");   // Error message
                    Console.WriteLine(ex.Message);
                }
                sr.Close();
            }
            // Set the values of the variables
            int maxentry = etime.Max();
            int minentry = etime.Min();
            int sumentry = etime.Sum();
            int avgentry = sumentry / 10;
            int maxpause = ptime.Max();
            int minpause = ptime.Min();
            int sumpause = ptime.Sum();
            int avgpause = sumpause / 10;
            int totaltime = sumentry + sumpause;
            int backcount = back.Sum();
            int minutes = 0, sec = 0;
            using (StreamWriter sw = new StreamWriter(b + ".txt"))  // Stream writer to write to another file
            {
                try
                {
                    // Write all the data
                    // Note the time conversion
                    sw.WriteLine("Number of records: 10");
                    minutes = minentry / 60; sec = minentry % 60;
                    sw.WriteLine("Minimum entry time: "+minutes+":"+sec);
                    minutes = maxentry / 60; sec = maxentry % 60;
                    sw.WriteLine("Maximum entry time: " + minutes + ":" + sec);
                    minutes = avgentry / 60; sec = avgentry % 60;
                    sw.WriteLine("Average entry time: " + minutes + ":" + sec);
                    minutes = minpause / 60; sec = minpause % 60;
                    sw.WriteLine("Minimum inter-record time: " + minutes + ":" + sec);
                    minutes = maxpause / 60; sec = maxpause % 60;
                    sw.WriteLine("Maximum inter-record time: " + minutes + ":" + sec);
                    minutes = avgpause / 60; sec = avgpause % 60;
                    sw.WriteLine("Average inter-record time: " + minutes + ":" + sec);
                    minutes = totaltime / 60; sec = totaltime % 60;
                    sw.WriteLine("Total time: " + minutes + ":" + sec);
                    sw.WriteLine("Backspace count: "+backcount);
                }

                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                }
                sw.Close();
                update();   // Update the list everytime sw writes to a file
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox1.Text))   // If all conditions are met
            {
                i = 0;
                b = textBox1.Text;
                analyze(i1,b);  // Calls for analysis of file
                label1.Text = "";
            }
            if (String.IsNullOrEmpty(textBox1.Text))
            {
                label1.ForeColor = System.Drawing.Color.Red;
                label1.Text = "Please give a name to the analysis file.";   // Alarm for filling in all details
                button2.Enabled = false;
            }
            textBox1.Text = "";
            button2.Enabled = false;
        }
    }
}

